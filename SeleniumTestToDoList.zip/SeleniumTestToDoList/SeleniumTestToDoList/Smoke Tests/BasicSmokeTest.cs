﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;

namespace SeleniumTestToDoList
{
    public class SeleniumTest
    {
        [TestFixture]
        public class SmokeTest
        {
            private IWebDriver driver;
            private StringBuilder verificationErrors;
            private string baseURL;
            private bool acceptNextAlert = true;

            [SetUp]
            public void SetupTest()
            {
                driver = new FirefoxDriver();
                baseURL = "https://todomvc.com/examples/react/#/";
                verificationErrors = new StringBuilder();
            }

            [TearDown]
            public void TeardownTest()
            {
                try
                {
                    driver.Quit();
                }
                catch (Exception)
                {
                    // Ignore errors if unable to close the browser
                }
                Assert.AreEqual("", verificationErrors.ToString());
            }
            [Test]
            public void EnterCharactersToCreateNewToDo()
            {

                driver.Navigate().GoToUrl("https://todomvc.com/examples/react/#/");
                driver.FindElement(By.XPath("//input[@value='']")).Click();
                driver.FindElement(By.XPath("//input[@value='']")).Clear();
                driver.FindElement(By.XPath("//input[@value='']")).SendKeys("test");
                driver.FindElement(By.XPath("//input[@value='']")).SendKeys(Keys.Enter);
                driver.FindElement(By.XPath("//div/input")).Click();

                //Identify Assert element
                IWebElement ChecklistButton = driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='todos'])[1]/following::label[2]"));

                //Assert
                Assert.That(ChecklistButton.Displayed, Is.True);
            }

            [Test]
            public void TickEntryIntoCompleted()
            {
                driver.Navigate().GoToUrl("https://todomvc.com/examples/react/#/");
                driver.FindElement(By.XPath("//input[@value='']")).Click();
                driver.FindElement(By.XPath("//input[@value='']")).Clear();
                driver.FindElement(By.XPath("//input[@value='']")).SendKeys("test");
                driver.FindElement(By.XPath("//input[@value='']")).SendKeys(Keys.Enter);
                driver.FindElement(By.XPath("//div/input")).Click();
                driver.FindElement(By.LinkText("Completed")).Click();
                //Identify Assert element
                IWebElement CompletedTabCheckToDo = driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='todos'])[1]/following::label[2]"));

                //Assert
                Assert.That(CompletedTabCheckToDo.Displayed, Is.True);
            }

            [Test]
            public void TickEntryExistsIntoCompleted()
            {
                driver.Navigate().GoToUrl("https://todomvc.com/examples/react/#/");
                driver.FindElement(By.XPath("//input[@value='']")).Click();
                driver.FindElement(By.XPath("//input[@value='']")).Clear();
                driver.FindElement(By.XPath("//input[@value='']")).SendKeys("test");
                driver.FindElement(By.XPath("//input[@value='']")).SendKeys(Keys.Enter);
                driver.FindElement(By.LinkText("Active")).Click();
                //Identify Assert element
                IWebElement ActiveTabCheckToDo = driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='todos'])[1]/following::label[2]"));

                //Assert
                Assert.That(ActiveTabCheckToDo.Displayed, Is.True);
            }

            [Test]
            public void DeleteEntry()
            {
                driver.Navigate().GoToUrl("https://todomvc.com/examples/react/#/");
                driver.FindElement(By.XPath("//input[@value='']")).Click();
                driver.FindElement(By.XPath("//input[@value='']")).Clear();
                driver.FindElement(By.XPath("//input[@value='']")).SendKeys("test");
                driver.FindElement(By.XPath("//input[@value='']")).SendKeys(Keys.Enter);
                driver.FindElement(By.XPath("//input[@value='']")).Click();
                driver.FindElement(By.XPath("//input[@value='']")).Clear();
                driver.FindElement(By.XPath("//input[@value='']")).SendKeys("test");
                driver.FindElement(By.XPath("//input[@value='']")).SendKeys(Keys.Enter);
                driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='test'])[1]/following::label[1]")).Click();
                driver.FindElement(By.XPath("//li[2]/div/button")).Click();
                driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='todos'])[1]/following::label[2]")).Click();
                //Identify Assert element
                IWebElement FirstEntry = driver.FindElement(By.XPath("(.//*[normalize-space(text()) and normalize-space(.)='todos'])[1]/following::label[2]"));

                //Assert
                Assert.That(FirstEntry.Displayed, Is.True);
            }

            [Test]
            public void CheckLinks()
            {
                driver.Navigate().GoToUrl("https://todomvc.com/examples/react/#/");
                driver.FindElement(By.LinkText("petehunt")).Click();
                driver.Navigate().GoToUrl("https://todomvc.com/examples/react/#/");
                driver.FindElement(By.LinkText("TodoMVC")).Click();
                driver.Navigate().GoToUrl("https://todomvc.com/examples/react/#/");

                // Something I tried - Tried asserting the object with the link
                IWebElement PeteHuntLink = driver.FindElement(By.LinkText("petehunt"));
                IWebElement ToDoMVC = driver.FindElement(By.LinkText("TodoMVC"));
                //Assert.AreEqual(PeteHuntLink, "https://github.com/petehunt/");

                Assert.That(PeteHuntLink.Displayed, Is.True);
                Assert.That(ToDoMVC.Displayed, Is.True);
            }
        }
    }
}
